package com.example.myonclicky;
//NOT USED...
public interface BlankFragmentInterface {
}
