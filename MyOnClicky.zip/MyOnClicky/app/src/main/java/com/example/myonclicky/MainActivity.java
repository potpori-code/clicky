package com.example.myonclicky;

import static android.app.PendingIntent.getActivity;

import static java.security.AccessController.getContext;
import com.example.myonclicky.BlankFragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnOne;

    private ViewPager mViewPager;       //Not fully implemented, just testing


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);     //In this mode setOnClickListener() can be received in MainActivity()
        setContentView(R.layout.fragment_blank);     //This is the GUI I am planning to use. Where the OnClickListener events are handled in BlankFragment.java . But now it's not! :-(
        //loadFragment(new BlankFragment(), false);

        //mViewPager = (ViewPager) findViewById(R.id.tongbesar);      //Must matches setContentView() xml !!!?

/*
        //OK THESE WORKS on activity_main.xml only!!!
        btnOne = findViewById(R.id.btnOne);

        btnOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "BtnOne2 for Activity main", Toast.LENGTH_LONG).show();
            }
        });
*/


    }
/*
    @Override
    protected View onCreateView()

*/
@SuppressLint("ResourceType")
public void loadFragment(Fragment fragment, Boolean bool) {
    FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
    transaction.replace(R.layout.activity_main, fragment);
    if (bool)
        transaction.addToBackStack(null);
    transaction.commit();
}
/*
public void meClicking(View view)
{
    //Toast.makeText(getApplicationContext(), "Clicked from MainActivity", Toast.LENGTH_LONG).show();
    // bf = null; //= new BlankFragment();
    //assert bf != null;
    BlankFragment.subClassFunction();
}
*/
}
